package com.mycompany.myapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import android.support.v4.app.Fragment;

public class StandardFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.tab_standard, container, false);

        final MainActivity main = (MainActivity)getActivity();

        Button b1 = view.findViewById(R.id.btnTopMovies);
        Button b2 = view.findViewById(R.id.btnPopularMovies);
        Button b3 = view.findViewById(R.id.btnTrendingMoviesDay);
        Button b4 = view.findViewById(R.id.btnTrendingMoviesWeek);

        b1.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    main.loadCategory("/movie/top_rated");
                }
            });

        b2.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    main.loadCategory("/movie/popular");
                }
            });

        b3.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    main.loadCategory("/trending/movie/day");
                }
            });

        b4.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    main.loadCategory("/trending/movie/week");
                }
            });

        return view;
    }
}
