package com.mycompany.myapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.view.ViewPager;
import android.support.design.widget.TabLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.Response;
import com.android.volley.VolleyError;

public class MainActivity extends AppCompatActivity {

    private static final String TMDB_API_KEY = "74f3ce931d65ebda1f77ef24eac2625f";

    // Fronta pre sieťové požiadavky
    private RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Inicializácia Volley fronty
        // Inicializuje sa hneď, ako sa spustí hlavná aktivita.
        queue = Volley.newRequestQueue(this);

        // 2. Nastavenie ViewPager a TabLayout
        // Všetky ID (viewPager, tabLayout) sú overené v activity_main.xml
        ViewPager viewPager = (ViewPager)findViewById(R.id.viewPager);

        // Použitie triedy TabsAdapter na dodanie fragmentov
        viewPager.setAdapter(new TabsAdapter(getSupportFragmentManager()));

        TabLayout tabLayout = (TabLayout)findViewById(R.id.tabLayout);
        tabLayout.setupWithViewPager(viewPager);
    }

    // ---------------------------------------------------------------------------------------------
    // TMDB REQUEST (Logika na vykonanie HTTP požiadavky)
    // ---------------------------------------------------------------------------------------------
    private void makeRequest(String url) {
        StringRequest req = new StringRequest(
            Request.Method.GET,
            url,
            new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    // Požiadavka bola úspešná - zatiaľ len vypíšeme do LogCat/System.out
                    System.out.println("TMDB OK: " + response);
                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Požiadavka zlyhala
                    System.out.println("TMDB ERROR: " + error.toString());
                }
            }
        );

        // Pridanie požiadavky do fronty
        // (Toto môže hodiť chybu, ak je fronta 'queue' null, ale v onCreate ju inicializujeme)
        if (queue != null) {
            queue.add(req);
        } else {
            System.out.println("Volley queue nie je inicializovaná!");
        }
    }

    // ---------------------------------------------------------------------------------------------
    // PUBLIC METÓDY VOLANÉ Z FRAGMENTOV
    // Tieto metódy odstraňujú chybu "Unknown method"
    // ---------------------------------------------------------------------------------------------

    // Volané zo StandardFragment (Top rated, Popular, Trending...)
    public void loadCategory(String endpoint) {
        String url = "https://api.themoviedb.org/3" + endpoint +
            "?api_key=" + TMDB_API_KEY;

        makeRequest(url);
    }

    // Volané zo StreamingFragment (Netflix, Disney+ atď.)
    public void loadCategoryStreaming(String providerId) {
        String url =
            "https://api.themoviedb.org/3/discover/movie" +
            "?api_key=" + TMDB_API_KEY +
            "&with_watch_providers=" + providerId +
            "&watch_region=SK" +
            "&with_watch_monetization_types=flatrate";

        makeRequest(url);
    }
}

