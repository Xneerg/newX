package com.mycompany.myapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.support.v4.app.Fragment;

public class StreamingFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.tab_streaming, container, false);

        final MainActivity main = (MainActivity)getActivity();

        view.findViewById(R.id.btnNetflixMovies).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { main.loadCategoryStreaming("8"); }
            });

        view.findViewById(R.id.btnDisneyMovies).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { main.loadCategoryStreaming("337"); }
            });

        view.findViewById(R.id.btnHBOMovies).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { main.loadCategoryStreaming("384"); }
            });

        view.findViewById(R.id.btnAmazonMovies).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { main.loadCategoryStreaming("119"); }
            });

        view.findViewById(R.id.btnAppleMovies).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { main.loadCategoryStreaming("350"); }
            });

        return view;
    }
}
